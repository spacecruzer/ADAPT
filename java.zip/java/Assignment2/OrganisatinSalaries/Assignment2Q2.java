package Assignment-2.OrganisatinSalaries;

public class Assignment2Q2 {
    public static void main(String[] args){
        Manager manager = new Manager();
        m.salary(5);
        
    }
}
