package Assignment2.DessertShop;

abstract class Dessert {
    abstract void getCost(int h);
}
