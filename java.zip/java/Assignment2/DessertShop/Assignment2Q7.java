package Assignment2.DessertShop;

public class Assignment2Q7 {
    public static void main(String[] args){
        IceCream i1 = new IceCream();
        i1.addIceCream(3);
        Candy c= new Candy();
        c.addCandy(3);
    }
}
