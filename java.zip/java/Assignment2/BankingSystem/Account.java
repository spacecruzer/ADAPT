package BankingSystem;

public class Account {
    int balance;
    double intererst;
    int creditLimit;
    int withdrawl_amount;
}
