package BankingSystem;

public class AssignmentQ3 {
    public static void main(String[] args){
        SavingsAccount s =new SavingsAccount(10000,2.50);
        s.getWithdrawl(2000);
        s.getCash();

        
    }
}
