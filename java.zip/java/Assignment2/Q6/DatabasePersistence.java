package Assignment2.Q6;

public class DatabasePersistence extends Persistence {
    @Override
    public String persist(){
        System.out.println("this is database file");
        return null;

    }
}
