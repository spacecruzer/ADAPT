package Assignment2.Q6;

public abstract class Persistence {
    abstract public String persist();
}
