package Assignment2.Q6;

public class FilePersistence extends Persistence{
    
    @Override
    public String persist(){
        System.out.println("Persistence File");
        return null;

    }
}
