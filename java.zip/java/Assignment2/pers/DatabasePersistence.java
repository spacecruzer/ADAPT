package pers;

public class DatabasePersistence extends Persistence {
    @Override
    void persist(){
        System.out.println("This is a method");
    }
}
