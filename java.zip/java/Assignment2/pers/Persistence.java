package pers;

abstract class Persistence {
  abstract void persist();
}
