package pers;

public class Assignment2Q6 {
    public static void main(String[] args){
        Persistence p =new Persistence();
        p.persist();
    }
}
