package DrawObjects;

 class Cube extends Shape {
    @Override
    void draw(){
        System.out.println("DRAW A CUBE");
    }
}
