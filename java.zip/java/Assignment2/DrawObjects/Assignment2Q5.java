package DrawObjects;

public class Assignment2Q5 {
    public static void main(String[] args){
        Cube c= new Cube();
    c.draw();
    }
}
