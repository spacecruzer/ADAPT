package DrawObjects;

abstract class Shape {
     abstract void draw();
}
