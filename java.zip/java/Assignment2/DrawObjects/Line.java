package DrawObjects;

public class line extends Shape {
    @Override
    void draw(){
        System.out.println("DRAW A LINE");
    }
}
