package DrawObjects;

public class Rectangle extends Shape {
    @Override
    void draw(){
        System.out.println("DRAW A RECTANLE");
    }
}
