package Assignment5.WorkingCities;

public class Trader {
    String name;
    String city;
    public Trader(String name,String city){
       this.name=name;
        this.city= city;
    }
}
