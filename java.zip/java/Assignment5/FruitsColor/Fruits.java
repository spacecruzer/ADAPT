package Assignment5.FruitsColor;

import java.util.ArrayList;

public class Fruits {
    String name;
    int calories;
    int price;
    String color;   
    Fruits(String name,int calories,int price,String color){
        this.name = name;
        this.calories=calories;
        this.price=price;
        this.color=color;
 }

}