package Orders;

interface Order {
    void criteria();
    
}
