package Orders;

public class Assignment4Q2 implements Order {
    public static void main(String[] args){

    }

    @Override
    public void criteria() {
        

    }

}
