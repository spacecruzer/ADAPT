package FunctionalInterfaces;

interface Predicate {
    boolean test(int t);   
}
