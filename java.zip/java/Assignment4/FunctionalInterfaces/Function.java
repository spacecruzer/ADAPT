package FunctionalInterfaces;

interface Function {
    void apply(int i);
}
