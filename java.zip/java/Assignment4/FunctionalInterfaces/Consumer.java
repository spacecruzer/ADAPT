package FunctionalInterfaces;

interface Consumer {
 void consumerFunc();   
}
