package FunctionalInterfaces;

interface Supplier {
    void supplyFunc();
}
