package FirstLetter;

public class StringFirst {
    void getFirst(String s){
        char a= s.charAt(0);
        char ch= Character.toUpperCase(a);
        System.out.println("the first letter is "+ch);
    }
}
