package ArithmaticOperation;

interface Operations {
    void fun(int a,int b);
}
