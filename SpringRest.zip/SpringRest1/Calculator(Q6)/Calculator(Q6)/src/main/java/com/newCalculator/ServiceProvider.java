package com.newCalculator;

public class ServiceProvider {
  public int addService(int a,int b) {
	  return a+b;
  }
  public int subractionService(int a,int b) {
	  return a-b;
  }
  public int multiplicationService(int a,int b) {
	  return a*b;
  }
  public int divisionService(int a,int b) {
	  return a/b;
  }
}
