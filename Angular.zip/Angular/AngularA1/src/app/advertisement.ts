export class Advertisement {
    constructor(
        public title: string,
        public name: string,
        public category: string,
        public description: string
      ) {  }
}
