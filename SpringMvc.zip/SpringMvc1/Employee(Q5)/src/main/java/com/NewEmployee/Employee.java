package com.NewEmployee;

import java.util.ArrayList;

public class Employee {
	 int id;
		private String name;
		private String address;
		private long Contact;
		private String department;
		private String designation;
		public String getDepartment() {
			return department;
		}
		public void setDepartment(String department) {
			this.department = department;
		}
		public String getDesignation() {
			return designation;
		}
		public void setDesignation(String designation) {
			this.designation = designation;
		}
		public int getSalary() {
			return Salary;
		}
		public void setSalary(int salary) {
			Salary = salary;
		}
		private int Salary;
		
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public long getContact() {
			return Contact;
		}
		public void setContact(long contact) {
			Contact = contact;
		}
		
		
		
		
}
