package com.newInterest;

public class ServiceProvider {
  public double getinterest(int a,int b,int c) {
	  return (a*b*c)/100;
  }
}
