import React, { Component } from 'react'

 class about extends Component {
    render() {
        return (
            <div>
                <h1>You Choose Home</h1>
            </div>
        )
    }
}

export default about
