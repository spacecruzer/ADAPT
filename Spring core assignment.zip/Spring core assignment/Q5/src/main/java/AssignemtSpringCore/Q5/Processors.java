package AssignemtSpringCore.Q5;



public interface Processors {
	public void process();

}
