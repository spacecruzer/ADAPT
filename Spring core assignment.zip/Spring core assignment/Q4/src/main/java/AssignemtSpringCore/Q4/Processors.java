package AssignemtSpringCore.Q4;



public interface Processors {
	public void process();

}
